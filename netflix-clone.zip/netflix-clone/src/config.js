// replace below firebase config with your own

const firebaseConfig = {
  apiKey: "AIzaSyChOvVsrZlwECCbsBCwU6ax64Y-LmPUBIc",
  authDomain: "netflix-clone-929db.firebaseapp.com",
  projectId: "netflix-clone-929db",
  storageBucket: "netflix-clone-929db.firebasestorage.app",
  messagingSenderId: "121529229342",
  appId: "1:121529229342:web:274728d7a4a6287c328e0f",
  measurementId: "G-519N5D8W68"
};


// craete a/c on themoviedb.org and replace access token below


const TMDB_Access_Key="eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJlZTNlNzczZDIwY2M2Y2NhNWQ4YWVjMjQzNTdlNDc1ZCIsInN1YiI6IjY2MjIyMDFhYWUzODQzMDE4NzJhNTJjMiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.vPDW2QwNr9hIRdOvJx_x8hbHnDYZGHMtnZwfkqb3J8U";


  export {firebaseConfig, TMDB_Access_Key};